# Lettre de mission — ChatGPT Work — OPG V1

## Mission

Contre-auditer puis intégrer **conditionnellement** la brique `ZORAN_OPPOSED_PAIR_GATE_V1` dans le travail ZORAN en cours.

Ne pas toucher `main`. Ne rien fusionner ni déployer. Ne pas appliquer de patch réel aux ~800 objets. La mission est branche isolée + dry-run + preuves.

## Base à respecter

- loi Z1 inchangée ;
- jauge S active : ne pas la recopier dans OPG ; OPG consomme seulement des reçus S certifiés ;
- K3 existant inchangé : `NON()` est une négation de verdict, jamais un générateur d'opposé sémantique ;
- Amygdale reste l'étalon de veto ;
- ZMOS conserve identités, relations, provenance, reçus et rollback ;
- `ZORAN_CONSOLIDATION_ENGINE` reste `DRY_RUN_ONLY`.

## Travail demandé

1. vérifier le ZIP et `MANIFEST_SHA256.json` ;
2. exécuter les tests unitaires ;
3. exécuter `run_falsification_1m.py` et exiger exactement 1 000 000 cas, 0 violation ;
4. tenter de casser la pré-déclaration, la baseline commune, la parité des cadres, le fail-closed NON_MESURÉ, la séparation rollback/inverse/K3.NON et l'anti-compensation ;
5. adapter OPG au code K3 réel **sans modifier les tables K3** ;
6. ajouter les objets/reçus/relations ZMOS nécessaires ;
7. adapter le robot par ajout de guards et sorties seulement, sans lui permettre d'inventer un contraste ;
8. mettre à jour le plan canonique v1.1 vers v1.2 par patch documentaire borné ;
9. PRE/POST K3 + Amygdale ;
10. produire SHA, diff, tests, journal et rollback.

## Verdict attendu

- un seul falsificateur robuste → `REJECT`, pas d'intégration ;
- règle de contraste absente → `NON_MESURÉ`, jamais invention ;
- 1M PASS seul → `PASS_IMPLEMENTATION`, jamais « loi causalement prouvée » ;
- aucune mutation de `main`, aucun merge, aucun déploiement.
