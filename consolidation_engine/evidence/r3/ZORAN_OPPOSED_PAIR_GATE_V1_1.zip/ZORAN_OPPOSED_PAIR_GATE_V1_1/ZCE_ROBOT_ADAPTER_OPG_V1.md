# ZORAN_CONSOLIDATION_ENGINE — adapter OPG V1

## Règle

Le robot ne génère jamais librement un « opposé ».

Pour chaque patch/correction candidate :
1. rechercher une règle de contraste pré-déclarée dans le manifeste ;
2. si elle existe, produire `opposed_pair_spec` ;
3. si elle manque, émettre `PACK_REQUEST(kind=OPPOSED_PAIR_RULE)` et classer le contraste `NON_MESURÉ` ;
4. exécuter les deux branches exclusivement en sandbox/dry-run ;
5. produire les mêmes mesures multicadres pour les deux branches ;
6. résoudre les empreintes autorisées depuis les registres K3/ZMOS productifs ;
7. passer les cadres `opposed_pair_evidence` **et**
   `opposed_pair_direction` dans le PRE/POST K3 ;
8. laisser Amygdale veto ;
9. journaliser la paire et les reçus dans les sorties ZMOS.

## Interdictions

- ne pas utiliser le rollback comme branche opposée ;
- ne pas utiliser `K3.NON()` pour fabriquer le contraste ;
- ne pas moyenner les cadres ;
- ne pas fabriquer une règle de contraste quand elle manque ;
- ne pas promouvoir un patch si `opposed_pair_evidence != PASS` **ou**
  `opposed_pair_direction != PASS` lorsque la policy OPG est requise ;
- ne jamais traiter une empreinte déclarée dans le paquet comme liste de
  confiance productive ;
- aucune écriture réelle : la v1.0.x du robot reste `DRY_RUN_ONLY`.

## Nouveaux guards proposés

- `GUARD_OPPOSED_PAIR_PREREGISTERED`
- `GUARD_OPPOSED_PAIR_SAME_BASELINE`
- `GUARD_OPPOSED_PAIR_FRAME_PARITY`
- `GUARD_OPPOSED_PAIR_NO_ROLLBACK_CONFLATION`
- `GUARD_OPPOSED_PAIR_NO_K3_NEGATION_CONFLATION`
- `GUARD_OPPOSED_PAIR_NON_MEASURE_FAIL_CLOSED`
- `GUARD_OPPOSED_PAIR_NO_AVERAGE_MASKING`
- `GUARD_OPPOSED_PAIR_EXTERNAL_TRUST_REQUIRED`
- `GUARD_OPPOSED_PAIR_DIRECTION_FAIL_CLOSED`

## Sorties proposées

- `ZCE_OPPOSED_PAIR_SPECS_V1.json`
- `ZCE_OPPOSED_PAIR_RECEIPTS_V1.json`
- journal : `OPPOSED_PAIR_PREREGISTERED`, `OPPOSED_PAIR_MEASURED`, `OPPOSED_PAIR_K3_EVALUATED`
