# -*- coding: utf-8 -*-
"""
ZORAN — Opposed Pair Gate V1 (OPG)

Statut:
- outil falsifiable / brique d'architecture;
- ne modifie pas la loi Z1;
- ne redéfinit pas la jauge S;
- ne confond jamais opposition sémantique, négation K3, inverse et rollback.

Le gate consomme des mesures S déjà certifiées par cadre.
Il compare une transition candidate à un contraste pré-déclaré en utilisant
strictement les mêmes cadres, la même baseline et la même politique de mesure.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime
from typing import Any, Dict, Iterable, List, Set, Tuple

VERSION = "ZORAN-OPPOSED-PAIR-GATE-V1.1"

PASS = "PASS"
FAIL = "FAIL"
NON_MESURE = "NON_MESURÉ"

DIRECTIONAL_SUPPORT = "DIRECTIONAL_SUPPORT"
DIRECTION_REVERSED = "DIRECTION_REVERSED"
NON_DISCRIMINATING = "NON_DISCRIMINATING"
BOTH_DEGRADE = "BOTH_DEGRADE"
NEUTRAL = "NEUTRAL"
FRAME_CONFLICT = "FRAME_CONFLICT"
REJECT = "REJECT"

ALLOWED_CONTRAST_TYPES = {
    "POLAR_OPPOSITE",
    "NEGATIVE_CONTROL",
    "COUNTERFACTUAL_CONTROL",
    "INVERSE_PROVEN",
}

SPEC_KEYS = {
    "schema", "predeclared", "rule_id", "measurement_policy_id",
    "source_transition_id", "contrast_transition_id", "contrast_type",
    "required_frames", "critical_frames", "self_dual_predeclared",
    "baseline_tolerance", "effect_epsilon", "claims",
    "preregistration_receipt",
}
CLAIM_KEYS = {"inverse_equivalence", "inverse_proof_ref", "rollback_equivalence"}
PREREG_KEYS = {
    "schema", "authority_id", "authority_status", "registered_at", "rule_id",
    "source_transition_id", "contrast_transition_id", "measurement_policy_id",
    "required_frames_sha256", "result_observed", "receipt_sha256",
}
MEASUREMENT_KEYS = {
    "schema", "transition_id", "frame_id", "measurement_policy_id", "baseline_id",
    "horizon_id", "depth_id", "s_before", "s_after", "evidence_status",
    "certification_status", "observed_at", "receipt_sha256",
}

_HEX64 = re.compile(r"^[0-9a-f]{64}$")

def _canonical(obj: Any) -> bytes:
    return json.dumps(
        obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")

def _sha(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj)).hexdigest()

def canonical_sha256(obj: Any) -> str:
    return _sha(obj)

def _finite(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} doit être un réel fini")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} doit être fini")
    return value

def _score(value: Any, name: str) -> float:
    value = _finite(value, name)
    if value < 0.0 or value > 100.0:
        raise ValueError(f"{name} doit appartenir à [0,100]")
    return value

def _trust_set(value: Iterable[str] | None, name: str) -> Set[str]:
    if value is None:
        return set()
    if isinstance(value, (str, bytes)):
        raise ValueError(f"{name} doit être une collection d'empreintes")
    result = set(value)
    if any(not isinstance(item, str) or _HEX64.fullmatch(item) is None for item in result):
        raise ValueError(f"{name} contient une empreinte SHA-256 invalide")
    return result

def _time(value: Any, name: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} doit être un instant ISO-8601")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{name} doit être un instant ISO-8601") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{name} doit inclure un fuseau")
    return parsed

def _content_hash_valid(value: Dict[str, Any], hash_key: str) -> bool:
    if not isinstance(value.get(hash_key), str):
        return False
    body = {key: item for key, item in value.items() if key != hash_key}
    return value[hash_key] == _sha(body)

def _non_mesure(spec: Dict[str, Any], reasons: List[str], frames: Dict[str, Any],
                 stamp: bool) -> Dict[str, Any]:
    body = {
        "schema": "zoran.opposed_pair.receipt.v1.1",
        "version": VERSION,
        "pair_id": "PAIR-V1_1-" + _sha(spec),
        "k3_verdict": NON_MESURE,
        "directional_status": NON_MESURE,
        "direction_claim_eligible": False,
        "amygdala_recommendation": "VETO_NON_MESURE",
        "reasons": sorted(set(reasons)),
        "frames": {key: frames[key] for key in sorted(frames)},
        "critical_frames": list(spec.get("critical_frames", [])),
        "scope": "OPPOSED_PAIR_EVIDENCE_ONLY",
    }
    if stamp:
        body["receipt_id"] = "RCP-V1_1-" + _sha(body)
    return body

def stamp_preregistration(body: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(body)
    result["receipt_sha256"] = _sha(result)
    return result

def stamp_measurement(body: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(body)
    result["receipt_sha256"] = _sha(result)
    return result

def _reject(spec: Dict[str, Any], reasons: List[str], stamp: bool) -> Dict[str, Any]:
    body = {
        "schema": "zoran.opposed_pair.receipt.v1.1",
        "version": VERSION,
        "pair_id": "PAIR-V1_1-" + _sha(spec),
        "k3_verdict": FAIL,
        "directional_status": REJECT,
        "direction_claim_eligible": False,
        "amygdala_recommendation": "VETO_INVALID_PAIR",
        "reasons": sorted(set(reasons)),
        "frames": {},
        "critical_frames": list(spec.get("critical_frames", [])) if isinstance(spec, dict) else [],
        "scope": "OPPOSED_PAIR_EVIDENCE_ONLY",
    }
    if stamp:
        body["receipt_id"] = "RCP-V1_1-" + _sha(body)
    return body

def validate_spec(spec: Dict[str, Any]) -> List[str]:
    reasons: List[str] = []
    if not isinstance(spec, dict):
        return ["SPEC_NOT_OBJECT"]
    if set(spec) != SPEC_KEYS:
        reasons.append("SPEC_SCHEMA_NOT_CLOSED")
    if spec.get("schema") != "zoran.opposed_pair.spec.v1.1":
        reasons.append("BAD_SCHEMA")
    if spec.get("predeclared") is not True:
        reasons.append("NOT_PREDECLARED")
    if not isinstance(spec.get("rule_id"), str) or not spec.get("rule_id"):
        reasons.append("MISSING_RULE_ID")
    if not isinstance(spec.get("measurement_policy_id"), str) or not spec.get("measurement_policy_id"):
        reasons.append("MISSING_MEASUREMENT_POLICY")
    src = spec.get("source_transition_id")
    ctr = spec.get("contrast_transition_id")
    if not isinstance(src, str) or not src:
        reasons.append("MISSING_SOURCE_TRANSITION")
    if not isinstance(ctr, str) or not ctr:
        reasons.append("MISSING_CONTRAST_TRANSITION")
    if src == ctr:
        reasons.append("SELF_PAIR_UNSUPPORTED_FAIL_CLOSED")
    if spec.get("self_dual_predeclared") is not False:
        reasons.append("SELF_DUAL_UNSUPPORTED_FAIL_CLOSED")
    ctype = spec.get("contrast_type")
    if ctype not in ALLOWED_CONTRAST_TYPES:
        reasons.append("INVALID_CONTRAST_TYPE")
    claims = spec.get("claims", {})
    if not isinstance(claims, dict) or set(claims) != CLAIM_KEYS:
        reasons.append("CLAIMS_SCHEMA_NOT_CLOSED")
        claims = {}
    if claims.get("rollback_equivalence") is not False:
        reasons.append("ROLLBACK_CONFLATION")
    if ctype == "INVERSE_PROVEN":
        if (
            claims.get("inverse_equivalence") is not True
            or not isinstance(claims.get("inverse_proof_ref"), str)
            or _HEX64.fullmatch(claims.get("inverse_proof_ref", "")) is None
        ):
            reasons.append("UNPROVEN_INVERSE")
    elif claims.get("inverse_equivalence") is True or claims.get("inverse_proof_ref") not in (None, ""):
        reasons.append("UNPROVEN_INVERSE")
    required = spec.get("required_frames")
    critical = spec.get("critical_frames")
    if not isinstance(required, list) or not required or any(not isinstance(x, str) or not x for x in required):
        reasons.append("INVALID_REQUIRED_FRAMES")
        required = []
    elif len(set(required)) != len(required):
        reasons.append("DUPLICATE_REQUIRED_FRAME")
    if not isinstance(critical, list):
        reasons.append("INVALID_CRITICAL_FRAMES")
        critical = []
    else:
        if len(set(critical)) != len(critical):
            reasons.append("DUPLICATE_CRITICAL_FRAME")
        if any(x not in set(required) for x in critical):
            reasons.append("CRITICAL_FRAME_OUTSIDE_REQUIRED")
    tol = spec.get("baseline_tolerance", 0.0)
    try:
        tol = _finite(tol, "baseline_tolerance")
        if tol != 0.0:
            reasons.append("BASELINE_TOLERANCE_UNSUPPORTED_EXACT_BASELINE_REQUIRED")
    except ValueError:
        reasons.append("INVALID_BASELINE_TOLERANCE")
    eps = spec.get("effect_epsilon", 0.0)
    try:
        eps = _finite(eps, "effect_epsilon")
        if eps < 0 or eps > 100:
            reasons.append("EFFECT_EPSILON_OUT_OF_RANGE")
    except ValueError:
        reasons.append("INVALID_EFFECT_EPSILON")

    prereg = spec.get("preregistration_receipt")
    if not isinstance(prereg, dict) or set(prereg) != PREREG_KEYS:
        reasons.append("PREREGISTRATION_SCHEMA_NOT_CLOSED")
    else:
        expected = {
            "schema": "zoran.opposed_pair.preregistration.v1",
            "authority_status": PASS,
            "rule_id": spec.get("rule_id"),
            "source_transition_id": src,
            "contrast_transition_id": ctr,
            "measurement_policy_id": spec.get("measurement_policy_id"),
            "required_frames_sha256": _sha(sorted(required)),
            "result_observed": False,
        }
        if any(prereg.get(key) != value for key, value in expected.items()):
            reasons.append("PREREGISTRATION_BINDING_MISMATCH")
        if not isinstance(prereg.get("authority_id"), str) or not prereg.get("authority_id"):
            reasons.append("PREREGISTRATION_AUTHORITY_MISSING")
        try:
            _time(prereg.get("registered_at"), "registered_at")
        except ValueError:
            reasons.append("PREREGISTRATION_TIME_INVALID")
        if not _content_hash_valid(prereg, "receipt_sha256"):
            reasons.append("PREREGISTRATION_RECEIPT_HASH_INVALID")
    return sorted(set(reasons))

def _frame_class(source_delta: float, contrast_delta: float, eps: float) -> str:
    if source_delta > eps and contrast_delta < -eps:
        return DIRECTIONAL_SUPPORT
    if source_delta < -eps and contrast_delta > eps:
        return DIRECTION_REVERSED
    if source_delta > eps and contrast_delta > eps:
        return NON_DISCRIMINATING
    if source_delta < -eps and contrast_delta < -eps:
        return BOTH_DEGRADE
    return NEUTRAL

def _validate_measurement(
    branch: Any,
    *,
    frame: str,
    transition_id: str,
    policy_id: str,
    registered_at: datetime,
    trusted_measurements: Set[str],
) -> Tuple[List[str], List[str], Dict[str, Any] | None]:
    reasons: List[str] = []
    if not isinstance(branch, dict) or set(branch) != MEASUREMENT_KEYS:
        return ["MEASUREMENT_SCHEMA_NOT_CLOSED"], [], None
    expected = {
        "schema": "zoran.s.measurement-receipt.v1",
        "transition_id": transition_id,
        "frame_id": frame,
        "measurement_policy_id": policy_id,
    }
    if any(branch.get(key) != value for key, value in expected.items()):
        reasons.append("MEASUREMENT_BINDING_MISMATCH")
    for key in ("baseline_id", "horizon_id", "depth_id"):
        if not isinstance(branch.get(key), str) or not branch.get(key):
            reasons.append(f"MEASUREMENT_{key.upper()}_MISSING")
    try:
        observed_at = _time(branch.get("observed_at"), "observed_at")
        if observed_at <= registered_at:
            reasons.append("MEASUREMENT_NOT_AFTER_PREREGISTRATION")
    except ValueError:
        reasons.append("MEASUREMENT_TIME_INVALID")
    if not _content_hash_valid(branch, "receipt_sha256"):
        reasons.append("MEASUREMENT_RECEIPT_HASH_INVALID")
    missing_reasons: List[str] = []
    if branch.get("evidence_status") == NON_MESURE or branch.get("certification_status") == NON_MESURE:
        missing_reasons.append("MEASUREMENT_STATUS_NON_MESURE")
    elif branch.get("evidence_status") != PASS or branch.get("certification_status") != PASS:
        reasons.append("MEASUREMENT_EVIDENCE_NOT_PASS")
    if (
        isinstance(branch.get("receipt_sha256"), str)
        and branch["receipt_sha256"] not in trusted_measurements
    ):
        missing_reasons.append("MEASUREMENT_AUTHORITY_UNVERIFIED")
    values = None
    if not reasons and not missing_reasons:
        try:
            values = {
                "before": _score(branch.get("s_before"), "s_before"),
                "after": _score(branch.get("s_after"), "s_after"),
                "baseline_id": branch["baseline_id"],
                "horizon_id": branch["horizon_id"],
                "depth_id": branch["depth_id"],
            }
        except ValueError as exc:
            reasons.append(str(exc))
    return sorted(set(reasons)), sorted(set(missing_reasons)), values

def evaluate(
    spec: Dict[str, Any],
    measurements: Dict[str, Any],
    stamp: bool = True,
    *,
    trusted_preregistrations: Iterable[str] | None = None,
    trusted_measurements: Iterable[str] | None = None,
    trusted_inverse_proofs: Iterable[str] | None = None,
) -> Dict[str, Any]:
    reasons = validate_spec(spec)
    if reasons:
        return _reject(spec, reasons, stamp)

    try:
        prereg_trust = _trust_set(trusted_preregistrations, "trusted_preregistrations")
        measurement_trust = _trust_set(trusted_measurements, "trusted_measurements")
        inverse_trust = _trust_set(trusted_inverse_proofs, "trusted_inverse_proofs")
    except ValueError as exc:
        return _reject(spec, [str(exc)], stamp)
    prereg_sha = spec["preregistration_receipt"]["receipt_sha256"]
    if prereg_sha not in prereg_trust:
        return _non_mesure(spec, ["PREREGISTRATION_AUTHORITY_UNVERIFIED"], {}, stamp)
    if (
        spec["contrast_type"] == "INVERSE_PROVEN"
        and spec["claims"]["inverse_proof_ref"] not in inverse_trust
    ):
        return _non_mesure(spec, ["INVERSE_PROOF_UNVERIFIED"], {}, stamp)

    required = list(spec["required_frames"])
    expected = set(required)
    if not isinstance(measurements, dict) or set(measurements) != expected:
        # Une absence de cadre est inconnue; un cadre supplémentaire change le périmètre gelé.
        if isinstance(measurements, dict) and set(measurements).issubset(expected):
            return _non_mesure(spec, ["MISSING_REQUIRED_FRAME"], {}, stamp)
        return _reject(spec, ["FRAME_SET_MISMATCH"], stamp)

    eps = float(spec.get("effect_epsilon", 0.0))
    registered_at = _time(spec["preregistration_receipt"]["registered_at"], "registered_at")
    frame_results: Dict[str, Any] = {}
    missing: List[str] = []
    invalid = []

    for frame in required:
        datum = measurements[frame]
        if not isinstance(datum, dict) or set(datum) != {"source", "contrast"}:
            invalid.append(f"{frame}:FRAME_MEASUREMENT_SCHEMA_NOT_CLOSED")
            continue
        src = datum.get("source")
        ctr = datum.get("contrast")
        src_reasons, src_missing, src_values = _validate_measurement(
            src, frame=frame, transition_id=spec["source_transition_id"],
            policy_id=spec["measurement_policy_id"], registered_at=registered_at,
            trusted_measurements=measurement_trust,
        )
        ctr_reasons, ctr_missing, ctr_values = _validate_measurement(
            ctr, frame=frame, transition_id=spec["contrast_transition_id"],
            policy_id=spec["measurement_policy_id"], registered_at=registered_at,
            trusted_measurements=measurement_trust,
        )
        invalid.extend(f"{frame}:source:{reason}" for reason in src_reasons)
        invalid.extend(f"{frame}:contrast:{reason}" for reason in ctr_reasons)
        missing.extend(f"{frame}:source:{reason}" for reason in src_missing)
        missing.extend(f"{frame}:contrast:{reason}" for reason in ctr_missing)
        if src_missing or ctr_missing:
            continue
        if src_values is None or ctr_values is None:
            continue
        for key in ("baseline_id", "horizon_id", "depth_id"):
            if src_values[key] != ctr_values[key]:
                invalid.append(f"{frame}:{key.upper()}_MISMATCH")
        sb, sa = src_values["before"], src_values["after"]
        cb, ca = ctr_values["before"], ctr_values["after"]
        if sb != cb:
            invalid.append(f"{frame}:BASELINE_VALUE_MISMATCH")
        sd = sa - sb
        cd = ca - cb
        frame_results[frame] = {
            "source_delta_s": sd,
            "contrast_delta_s": cd,
            "classification": _frame_class(sd, cd, eps),
            "source_measurement_receipt_sha256": src["receipt_sha256"],
            "contrast_measurement_receipt_sha256": ctr["receipt_sha256"],
        }

    if invalid:
        return _reject(spec, invalid, stamp)

    if missing:
        return _non_mesure(spec, missing, frame_results, stamp)

    classes = [frame_results[f]["classification"] for f in required]
    if all(c == DIRECTIONAL_SUPPORT for c in classes):
        status = DIRECTIONAL_SUPPORT
    elif all(c == DIRECTION_REVERSED for c in classes):
        status = DIRECTION_REVERSED
    elif all(c == NON_DISCRIMINATING for c in classes):
        status = NON_DISCRIMINATING
    elif all(c == BOTH_DEGRADE for c in classes):
        status = BOTH_DEGRADE
    elif all(c == NEUTRAL for c in classes):
        status = NEUTRAL
    else:
        status = FRAME_CONFLICT

    amy = {
        DIRECTIONAL_SUPPORT: "NO_VETO_FROM_OPG",
        DIRECTION_REVERSED: "VETO_SOURCE_DIRECTION",
        NON_DISCRIMINATING: "HOLD_NON_DISCRIMINATING",
        BOTH_DEGRADE: "VETO_BOTH_DEGRADE",
        NEUTRAL: "HOLD_NEUTRAL",
        FRAME_CONFLICT: "VETO_FRAME_CONFLICT",
    }[status]

    body = {
        "schema": "zoran.opposed_pair.receipt.v1.1",
        "version": VERSION,
        "pair_id": "PAIR-V1_1-" + _sha(spec),
        # PASS = qualité/admissibilité de l'évidence paire, jamais vérité causale.
        "k3_verdict": PASS,
        "directional_status": status,
        "direction_claim_eligible": status == DIRECTIONAL_SUPPORT,
        "amygdala_recommendation": amy,
        "reasons": [],
        "frames": {k: frame_results[k] for k in sorted(frame_results)},
        "critical_frames": list(spec.get("critical_frames", [])),
        "scope": "OPPOSED_PAIR_EVIDENCE_ONLY",
    }
    if stamp:
        body["receipt_id"] = "RCP-V1_1-" + _sha(body)
    return body

def validate_receipt(receipt: Any) -> bool:
    required = {
        "schema", "version", "pair_id", "k3_verdict", "directional_status",
        "direction_claim_eligible", "amygdala_recommendation", "reasons", "frames",
        "critical_frames", "scope", "receipt_id",
    }
    if not isinstance(receipt, dict) or set(receipt) != required:
        return False
    if receipt.get("schema") != "zoran.opposed_pair.receipt.v1.1" or receipt.get("version") != VERSION:
        return False
    pair_id = receipt.get("pair_id")
    if (
        not isinstance(pair_id, str)
        or not pair_id.startswith("PAIR-V1_1-")
        or _HEX64.fullmatch(pair_id.removeprefix("PAIR-V1_1-")) is None
    ):
        return False
    verdict = receipt.get("k3_verdict")
    status = receipt.get("directional_status")
    reasons = receipt.get("reasons")
    if verdict not in {PASS, FAIL, NON_MESURE} or status not in {
        DIRECTIONAL_SUPPORT, DIRECTION_REVERSED, NON_DISCRIMINATING,
        BOTH_DEGRADE, NEUTRAL, FRAME_CONFLICT, NON_MESURE, REJECT,
    }:
        return False
    if not isinstance(reasons, list) or any(not isinstance(item, str) or not item for item in reasons):
        return False
    expected_amy = {
        DIRECTIONAL_SUPPORT: "NO_VETO_FROM_OPG",
        DIRECTION_REVERSED: "VETO_SOURCE_DIRECTION",
        NON_DISCRIMINATING: "HOLD_NON_DISCRIMINATING",
        BOTH_DEGRADE: "VETO_BOTH_DEGRADE",
        NEUTRAL: "HOLD_NEUTRAL",
        FRAME_CONFLICT: "VETO_FRAME_CONFLICT",
        NON_MESURE: "VETO_NON_MESURE",
        REJECT: "VETO_INVALID_PAIR",
    }
    if receipt.get("amygdala_recommendation") != expected_amy[status]:
        return False
    eligible = receipt.get("direction_claim_eligible")
    if eligible is not (verdict == PASS and status == DIRECTIONAL_SUPPORT):
        return False
    if verdict == FAIL and (status != REJECT or not reasons):
        return False
    if verdict == NON_MESURE and (status != NON_MESURE or not reasons):
        return False
    if verdict == PASS and (status in {REJECT, NON_MESURE} or reasons):
        return False
    if not isinstance(receipt.get("frames"), dict):
        return False
    if not isinstance(receipt.get("critical_frames"), list):
        return False
    receipt_id = receipt.get("receipt_id")
    if (
        not isinstance(receipt_id, str)
        or not receipt_id.startswith("RCP-V1_1-")
        or _HEX64.fullmatch(receipt_id.removeprefix("RCP-V1_1-")) is None
    ):
        return False
    body = {key: value for key, value in receipt.items() if key != "receipt_id"}
    return receipt_id == "RCP-V1_1-" + _sha(body)
