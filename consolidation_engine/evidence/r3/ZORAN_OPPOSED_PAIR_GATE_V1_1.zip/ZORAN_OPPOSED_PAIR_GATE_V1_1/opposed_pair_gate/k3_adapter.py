"""Adapter fail-closed vers l'algèbre K3 existante.

Le reçu OPG sépare la qualité de l'évidence de l'admissibilité de la direction
candidate. Une qualité de preuve ``PASS`` ne doit jamais autoriser une direction
inversée, neutre ou non discriminante.
"""
from .opposed_pair_gate import (
    BOTH_DEGRADE,
    DIRECTION_REVERSED,
    DIRECTIONAL_SUPPORT,
    FAIL,
    FRAME_CONFLICT,
    NEUTRAL,
    NON_DISCRIMINATING,
    NON_MESURE,
    PASS,
    REJECT,
    validate_receipt,
)

K3_EVIDENCE_FRAME_NAME = "opposed_pair_evidence"
K3_DIRECTION_FRAME_NAME = "opposed_pair_direction"


def _invalid_frame(name):
    return {
        "name": name,
        "verdict": FAIL,
        "directional_status": REJECT,
        "pair_id": None,
        "receipt_id": None,
        "reason": "OPG_RECEIPT_INTEGRITY_FAIL",
    }


def to_k3_required_frames(receipt):
    if not validate_receipt(receipt):
        return {
            K3_EVIDENCE_FRAME_NAME: _invalid_frame(K3_EVIDENCE_FRAME_NAME),
            K3_DIRECTION_FRAME_NAME: _invalid_frame(K3_DIRECTION_FRAME_NAME),
        }

    status = receipt["directional_status"]
    if receipt["k3_verdict"] == FAIL:
        direction_verdict = FAIL
        direction_reason = "OPG_PAIR_INVALID"
    elif receipt["k3_verdict"] == NON_MESURE:
        direction_verdict = NON_MESURE
        direction_reason = "OPG_EVIDENCE_NON_MESURE"
    elif status == DIRECTIONAL_SUPPORT and receipt["direction_claim_eligible"]:
        direction_verdict = PASS
        direction_reason = None
    elif status in {DIRECTION_REVERSED, BOTH_DEGRADE, FRAME_CONFLICT}:
        direction_verdict = FAIL
        direction_reason = "OPG_DIRECTION_VETO"
    elif status in {NON_DISCRIMINATING, NEUTRAL}:
        direction_verdict = NON_MESURE
        direction_reason = "OPG_DIRECTION_NOT_ESTABLISHED"
    else:
        direction_verdict = FAIL
        direction_reason = "OPG_DIRECTION_STATE_INVALID"

    common = {
        "verdict": receipt["k3_verdict"],
        "directional_status": status,
        "pair_id": receipt["pair_id"],
        "receipt_id": receipt["receipt_id"],
        "reason": None,
    }
    return {
        K3_EVIDENCE_FRAME_NAME: {"name": K3_EVIDENCE_FRAME_NAME, **common},
        K3_DIRECTION_FRAME_NAME: {
            "name": K3_DIRECTION_FRAME_NAME,
            **{**common, "verdict": direction_verdict, "reason": direction_reason},
        },
    }


def to_k3_required_frame(receipt):
    """Compatibilité sûre : renvoie le cadre de décision, jamais le seul PASS d'intégrité."""
    return to_k3_required_frames(receipt)[K3_DIRECTION_FRAME_NAME]
