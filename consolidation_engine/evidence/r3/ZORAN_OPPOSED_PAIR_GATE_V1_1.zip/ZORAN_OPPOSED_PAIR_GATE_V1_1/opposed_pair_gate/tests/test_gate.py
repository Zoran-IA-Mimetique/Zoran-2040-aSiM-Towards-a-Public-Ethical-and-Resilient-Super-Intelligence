import hashlib
import json
import unittest

from opposed_pair_gate.k3_adapter import to_k3_required_frame, to_k3_required_frames
from opposed_pair_gate.opposed_pair_gate import *


FRAMES = ["local", "pair", "system", "human", "planetary", "temporal"]
REGISTERED_AT = "2026-08-28T10:00:00+00:00"
OBSERVED_AT = "2026-08-28T10:01:00+00:00"


def sha(value):
    payload = json.dumps(
        value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def spec(**updates):
    value = {
        "schema": "zoran.opposed_pair.spec.v1.1",
        "predeclared": True,
        "rule_id": "RULE-TEST-001",
        "measurement_policy_id": "S-CANONICAL-ACTIVE",
        "source_transition_id": "T-A",
        "contrast_transition_id": "T-B",
        "contrast_type": "POLAR_OPPOSITE",
        "required_frames": list(FRAMES),
        "critical_frames": ["local", "system", "human", "planetary"],
        "self_dual_predeclared": False,
        "baseline_tolerance": 0.0,
        "effect_epsilon": 0.0,
        "claims": {
            "inverse_equivalence": False,
            "inverse_proof_ref": None,
            "rollback_equivalence": False,
        },
    }
    value.update(updates)
    prereg_body = {
        "schema": "zoran.opposed_pair.preregistration.v1",
        "authority_id": "TEST-AUTHORITY-NOT-PRODUCTION",
        "authority_status": PASS,
        "registered_at": REGISTERED_AT,
        "rule_id": value["rule_id"],
        "source_transition_id": value["source_transition_id"],
        "contrast_transition_id": value["contrast_transition_id"],
        "measurement_policy_id": value["measurement_policy_id"],
        "required_frames_sha256": sha(sorted(value["required_frames"])),
        "result_observed": False,
    }
    value["preregistration_receipt"] = stamp_preregistration(prereg_body)
    return value


def measurement(frame, transition, before, after, status=PASS, **updates):
    body = {
        "schema": "zoran.s.measurement-receipt.v1",
        "transition_id": transition,
        "frame_id": frame,
        "measurement_policy_id": "S-CANONICAL-ACTIVE",
        "baseline_id": "BASELINE-001",
        "horizon_id": "HORIZON-001",
        "depth_id": "DEPTH-001",
        "s_before": before,
        "s_after": after,
        "evidence_status": status,
        "certification_status": status,
        "observed_at": OBSERVED_AT,
    }
    body.update(updates)
    return stamp_measurement(body)


def measures(a, b, missing=None):
    result = {}
    for index, frame in enumerate(FRAMES):
        result[frame] = {
            "source": measurement(frame, "T-A", 50.0, 50.0 + a[index]),
            "contrast": measurement(frame, "T-B", 50.0, 50.0 + b[index]),
        }
    if missing is not None:
        current = result[missing]["contrast"]
        body = {key: value for key, value in current.items() if key != "receipt_sha256"}
        body["evidence_status"] = NON_MESURE
        body["certification_status"] = NON_MESURE
        result[missing]["contrast"] = stamp_measurement(body)
    return result


def trust(specification, observations):
    return {
        "trusted_preregistrations": {
            specification["preregistration_receipt"]["receipt_sha256"]
        },
        "trusted_measurements": {
            branch["receipt_sha256"]
            for datum in observations.values()
            for branch in datum.values()
        },
    }


def evaluate_trusted(specification, observations, **kwargs):
    trusted = trust(specification, observations)
    trusted.update(kwargs)
    return evaluate(specification, observations, **trusted)


class GateTests(unittest.TestCase):
    def test_directional_support(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["directional_status"], DIRECTIONAL_SUPPORT)
        self.assertEqual(receipt["k3_verdict"], PASS)
        self.assertTrue(receipt["direction_claim_eligible"])
        self.assertTrue(validate_receipt(receipt))

    def test_default_untrusted_preregistration_is_non_mesure(self):
        receipt = evaluate(spec(), measures([1] * 6, [-1] * 6))
        self.assertEqual(receipt["k3_verdict"], NON_MESURE)
        self.assertIn("PREREGISTRATION_AUTHORITY_UNVERIFIED", receipt["reasons"])

    def test_untrusted_measurement_is_non_mesure(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        receipt = evaluate(
            s,
            m,
            trusted_preregistrations={s["preregistration_receipt"]["receipt_sha256"]},
        )
        self.assertEqual(receipt["k3_verdict"], NON_MESURE)
        self.assertTrue(any("MEASUREMENT_AUTHORITY_UNVERIFIED" in r for r in receipt["reasons"]))

    def test_swapped_reverses_direction(self):
        s = spec()
        m = measures([-2] * 6, [3] * 6)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["directional_status"], DIRECTION_REVERSED)
        self.assertEqual(to_k3_required_frame(receipt)["verdict"], FAIL)

    def test_missing_is_non_mesure(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6, missing="planetary")
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], NON_MESURE)
        self.assertFalse(receipt["direction_claim_eligible"])

    def test_missing_frame_is_non_mesure(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        m.pop("temporal")
        receipt = evaluate(s, m, **trust(s, m))
        self.assertEqual(receipt["k3_verdict"], NON_MESURE)

    def test_extra_frame_is_fail(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        m["extra"] = m["local"]
        receipt = evaluate(s, m, **trust(s, m))
        self.assertEqual(receipt["k3_verdict"], FAIL)

    def test_rollback_conflation_rejected(self):
        s = spec()
        s["claims"]["rollback_equivalence"] = True
        m = measures([1] * 6, [-1] * 6)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], FAIL)
        self.assertIn("ROLLBACK_CONFLATION", receipt["reasons"])

    def test_unproven_inverse_rejected(self):
        s = spec(contrast_type="INVERSE_PROVEN")
        s["claims"]["inverse_equivalence"] = True
        s["claims"]["inverse_proof_ref"] = "not-a-sha"
        m = measures([1] * 6, [-1] * 6)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], FAIL)
        self.assertIn("UNPROVEN_INVERSE", receipt["reasons"])

    def test_inverse_proof_must_be_trusted(self):
        proof = "a" * 64
        claims = {
            "inverse_equivalence": True,
            "inverse_proof_ref": proof,
            "rollback_equivalence": False,
        }
        s = spec(contrast_type="INVERSE_PROVEN", claims=claims)
        m = measures([1] * 6, [-1] * 6)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], NON_MESURE)
        receipt = evaluate_trusted(s, m, trusted_inverse_proofs={proof})
        self.assertEqual(receipt["k3_verdict"], PASS)

    def test_baseline_identity_mismatch_rejected(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        body = {k: v for k, v in m["local"]["contrast"].items() if k != "receipt_sha256"}
        body["baseline_id"] = "BASELINE-OTHER"
        m["local"]["contrast"] = stamp_measurement(body)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], FAIL)

    def test_baseline_value_mismatch_rejected(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        body = {k: v for k, v in m["local"]["contrast"].items() if k != "receipt_sha256"}
        body["s_before"] = 49.0
        m["local"]["contrast"] = stamp_measurement(body)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], FAIL)

    def test_out_of_range_score_rejected(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        body = {k: v for k, v in m["local"]["source"].items() if k != "receipt_sha256"}
        body["s_after"] = 101.0
        m["local"]["source"] = stamp_measurement(body)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], FAIL)

    def test_measurement_must_follow_preregistration(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        body = {k: v for k, v in m["local"]["source"].items() if k != "receipt_sha256"}
        body["observed_at"] = REGISTERED_AT
        m["local"]["source"] = stamp_measurement(body)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["k3_verdict"], FAIL)

    def test_tampered_measurement_hash_rejected(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        trusted = trust(s, m)
        m["local"]["source"]["s_after"] += 1
        receipt = evaluate(s, m, **trusted)
        self.assertEqual(receipt["k3_verdict"], FAIL)

    def test_non_discriminating_holds_k3_direction(self):
        s = spec()
        m = measures([1] * 6, [1] * 6)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["directional_status"], NON_DISCRIMINATING)
        frames = to_k3_required_frames(receipt)
        self.assertEqual(frames["opposed_pair_evidence"]["verdict"], PASS)
        self.assertEqual(frames["opposed_pair_direction"]["verdict"], NON_MESURE)

    def test_frame_conflict_no_average_mask(self):
        s = spec()
        m = measures([2] * 6, [-2, -2, 3, -2, -2, -2])
        receipt = evaluate_trusted(s, m)
        self.assertEqual(receipt["directional_status"], FRAME_CONFLICT)
        self.assertFalse(receipt["direction_claim_eligible"])
        self.assertEqual(to_k3_required_frame(receipt)["verdict"], FAIL)

    def test_neutral_is_non_mesure_for_direction(self):
        s = spec()
        m = measures([0] * 6, [0] * 6)
        receipt = evaluate_trusted(s, m)
        self.assertEqual(to_k3_required_frame(receipt)["verdict"], NON_MESURE)

    def test_receipt_semantic_tamper_rejected_even_when_rehashed(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        receipt = evaluate_trusted(s, m)
        receipt["directional_status"] = DIRECTION_REVERSED
        body = {key: value for key, value in receipt.items() if key != "receipt_id"}
        receipt["receipt_id"] = "RCP-V1_1-" + sha(body)
        self.assertFalse(validate_receipt(receipt))

    def test_deterministic_receipt(self):
        s = spec()
        m = measures([1] * 6, [-1] * 6)
        trusted = trust(s, m)
        self.assertEqual(evaluate(s, m, **trusted), evaluate(s, m, **trusted))


if __name__ == "__main__":
    unittest.main()
