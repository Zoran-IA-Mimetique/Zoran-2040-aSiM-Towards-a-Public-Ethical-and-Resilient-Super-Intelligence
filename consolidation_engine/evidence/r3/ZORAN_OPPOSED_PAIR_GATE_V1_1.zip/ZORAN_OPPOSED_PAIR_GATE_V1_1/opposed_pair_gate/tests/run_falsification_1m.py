"""Campagne déterministe stratifiée : 1 000 000 évaluations, sans aléatoire."""
import hashlib
import json
from collections import Counter

from opposed_pair_gate.k3_adapter import to_k3_required_frame
from opposed_pair_gate.opposed_pair_gate import *


FRAMES = ["local", "pair", "system", "human", "planetary", "temporal"]
REGISTERED_AT = "2026-08-28T10:00:00+00:00"
OBSERVED_AT = "2026-08-28T10:01:00+00:00"


def sha(value):
    return hashlib.sha256(
        json.dumps(
            value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
    ).hexdigest()


def mk_spec():
    value = {
        "schema": "zoran.opposed_pair.spec.v1.1",
        "predeclared": True,
        "rule_id": "RULE-FALSIFICATION-001",
        "measurement_policy_id": "S-CANONICAL-ACTIVE",
        "source_transition_id": "T-A",
        "contrast_transition_id": "T-B",
        "contrast_type": "POLAR_OPPOSITE",
        "required_frames": list(FRAMES),
        "critical_frames": ["local", "system", "human", "planetary"],
        "self_dual_predeclared": False,
        "baseline_tolerance": 0.0,
        "effect_epsilon": 0.0,
        "claims": {
            "inverse_equivalence": False,
            "inverse_proof_ref": None,
            "rollback_equivalence": False,
        },
    }
    value["preregistration_receipt"] = stamp_preregistration({
        "schema": "zoran.opposed_pair.preregistration.v1",
        "authority_id": "FALSIFICATION-AUTHORITY-NOT-PRODUCTION",
        "authority_status": PASS,
        "registered_at": REGISTERED_AT,
        "rule_id": value["rule_id"],
        "source_transition_id": value["source_transition_id"],
        "contrast_transition_id": value["contrast_transition_id"],
        "measurement_policy_id": value["measurement_policy_id"],
        "required_frames_sha256": sha(sorted(value["required_frames"])),
        "result_observed": False,
    })
    return value


def measurement(frame, transition, before, after, status=PASS):
    return stamp_measurement({
        "schema": "zoran.s.measurement-receipt.v1",
        "transition_id": transition,
        "frame_id": frame,
        "measurement_policy_id": "S-CANONICAL-ACTIVE",
        "baseline_id": "BASELINE-001",
        "horizon_id": "HORIZON-001",
        "depth_id": "DEPTH-001",
        "s_before": before,
        "s_after": after,
        "evidence_status": status,
        "certification_status": status,
        "observed_at": OBSERVED_AT,
    })


def measurements(a, b, missing=None):
    result = {}
    for frame, x, y in zip(FRAMES, a, b):
        result[frame] = {
            "source": measurement(frame, "T-A", 50.0, 50.0 + x),
            "contrast": measurement(frame, "T-B", 50.0, 50.0 + y),
        }
    if missing is not None:
        frame = FRAMES[missing]
        old = result[frame]["contrast"]
        result[frame]["contrast"] = measurement(
            frame, "T-B", old["s_before"], old["s_after"], NON_MESURE
        )
    return result


def trusted(specification, observations):
    return {
        "trusted_preregistrations": {
            specification["preregistration_receipt"]["receipt_sha256"]
        },
        "trusted_measurements": {
            branch["receipt_sha256"]
            for datum in observations.values()
            for branch in datum.values()
        },
    }


def case(index):
    category = index % 8
    seed = index // 8
    a = [1 + ((seed * (7 + 2 * frame) + 3 * frame) % 10) for frame in range(6)]
    b = [1 + ((seed * (11 + 2 * frame) + 5 * frame) % 10) for frame in range(6)]
    specification = mk_spec()
    missing = None
    if category == 0:
        source, contrast, expected = a, [-value for value in b], DIRECTIONAL_SUPPORT
    elif category == 1:
        source, contrast, expected = [-value for value in a], b, DIRECTION_REVERSED
    elif category == 2:
        source, contrast, expected = a, b, NON_DISCRIMINATING
    elif category == 3:
        source, contrast, expected = [-value for value in a], [-value for value in b], BOTH_DEGRADE
    elif category == 4:
        source, contrast, expected = [0] * 6, [0] * 6, NEUTRAL
    elif category == 5:
        source = a
        contrast = [-b[frame] if frame % 2 == 0 else b[frame] for frame in range(6)]
        expected = FRAME_CONFLICT
    elif category == 6:
        source, contrast, expected = a, [-value for value in b], NON_MESURE
        missing = seed % 6
    else:
        source, contrast, expected = a, [-value for value in b], REJECT
        mutation = seed % 6
        if mutation == 0:
            specification["predeclared"] = False
        elif mutation == 1:
            specification["contrast_transition_id"] = specification["source_transition_id"]
        elif mutation == 2:
            specification["rule_id"] = ""
        elif mutation == 3:
            specification["claims"]["rollback_equivalence"] = True
        elif mutation == 4:
            specification["claims"]["inverse_equivalence"] = True
        else:
            specification["contrast_type"] = "INVALID"
    return specification, measurements(source, contrast, missing), expected, source, contrast


def swapped_outcomes(source, contrast):
    return measurements(contrast, source)


def run(total=1_000_000):
    counts = Counter()
    violations = []
    for index in range(total):
        specification, observed, expected, source, contrast = case(index)
        receipt = evaluate(specification, observed, stamp=False, **trusted(specification, observed))
        got = receipt["directional_status"]
        counts[got] += 1
        if got != expected:
            violations.append({"index": index, "expected": expected, "got": got})
            if len(violations) >= 20:
                break

        if got in (DIRECTIONAL_SUPPORT, DIRECTION_REVERSED):
            swapped = swapped_outcomes(source, contrast)
            swapped_receipt = evaluate(
                specification, swapped, stamp=False, **trusted(specification, swapped)
            )
            expected_swap = DIRECTION_REVERSED if got == DIRECTIONAL_SUPPORT else DIRECTIONAL_SUPPORT
            if swapped_receipt["directional_status"] != expected_swap:
                violations.append({
                    "index": index,
                    "property": "SWAP_OUTCOMES",
                    "expected": expected_swap,
                    "got": swapped_receipt["directional_status"],
                })
                break

        if got in {DIRECTION_REVERSED, BOTH_DEGRADE, FRAME_CONFLICT}:
            if to_k3_required_frame({**receipt, "receipt_id": "RCP-V1_1-" + sha(receipt)})["verdict"] != FAIL:
                violations.append({"index": index, "property": "K3_FAIL_CLOSED_VETO"})
                break

    executed = sum(counts.values())
    return {
        "schema": "zoran.opg.falsification.v1.1",
        "cases_requested": total,
        "cases_executed": executed,
        "counts": dict(sorted(counts.items())),
        "violations": len(violations),
        "first_violations": violations,
        "status": "PASS_1M_IMPLEMENTATION_GATE" if not violations and executed == total else "FAIL",
        "interpretation": (
            "Validation d'invariants logiciels sur corpus synthétique/adversarial; "
            "ne constitue pas une validation empirique universelle de causalité."
        ),
    }


if __name__ == "__main__":
    print(json.dumps(run(), ensure_ascii=False, indent=2, sort_keys=True))
