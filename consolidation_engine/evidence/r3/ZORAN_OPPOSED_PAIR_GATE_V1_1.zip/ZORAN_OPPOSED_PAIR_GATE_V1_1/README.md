# ZORAN — Opposed Pair Gate V1.1 (candidat réparé R3)

**Objet :** récupérer l'ancienne intuition de « symétrie opposée » sous une forme falsifiable et compatible avec Z1, K3, Amygdale et ZMOS.

## Décision architecturale

La brique n'est **pas** une nouvelle loi Z1. C'est un outil de contraste déterministe.
La V1 originale a été falsifiée par le robot R3 puis rejetée. La V1.1 ferme
les acceptations indues observées : schémas ouverts, absence de liaison du
préréférencement au contenu, mesures non certifiées/non liées, tolérance de
baseline non bornée et reçu K3 forgeable.

Elle impose :
1. un contraste/opposé déclaré **avant** le résultat, dans un reçu haché ;
2. les mêmes cadres, la même baseline et la même politique de mesure ;
3. une comparaison cadre par cadre, sans moyenne compensatoire ;
4. `NON_MESURÉ` dès qu'un cadre requis manque ;
5. séparation stricte `OPPOSÉ != NON(K3) != INVERSE != ROLLBACK` ;
6. une liste de confiance externe pour les reçus de pré-enregistrement, de
   mesure et, le cas échéant, la preuve d'inverse ;
7. des scores S bornés à `[0,100]` et des temps ISO-8601 avec fuseau.

## Placement

`NLP/Frames → pré-enregistrement → mesures S candidate + contraste → OPG → K3 → Amygdale → réponse/action → ZMOS`

K3 n'est pas modifié : `NON()` reste un opérateur sur verdicts. L'adapter
publie deux cadres distincts : `opposed_pair_evidence` pour la qualité des
preuves et `opposed_pair_direction` pour la décision. Le second n'est `PASS`
que pour `DIRECTIONAL_SUPPORT`; une direction inversée ou conflictuelle vaut
`FAIL`, une direction neutre ou non discriminante reste `NON_MESURÉ`.

Sans liste de confiance fournie par l'appelant, la sortie est volontairement
`NON_MESURÉ`. Le hash local rend l'altération détectable mais ne crée ni
autorité productive ni ancrage externe.

## Promotion

Le million de tests livré ici valide des **invariants d'implémentation**. Il ne
démontre pas une loi causale universelle. Une validation empirique et des
autorités productives restent nécessaires domaine par domaine.

## Rejeu robot R3

- tests unitaires/adversariaux V1.1 : **20/20 PASS** ;
- campagne synthétique/adversariale : **1 000 000/1 000 000 PASS** ;
- violations d'invariant : **0** ;
- intégration au runtime canonique Zoran : **NON_MESURÉE / non promue** ;
- validation causale/scientifique externe : **NON_MESURÉE**.

La brique est donc livrée comme **candidat borné**, à soumettre au runtime et
aux autorités productives K3/Amygdala. Elle ne ferme ni la promotion globale ni
le pack request des deux autorités productives distinctes.
