# ZORAN 0 — patch au plan canonique minimal v1.2

**Base :** `ZORAN-PLAN-CANONIQUE-MINIMAL:v1.1`  
**Nature :** extension bornée ; ne réécrit ni Z1, ni K3, ni Amygdale, ni ZMOS.  
**Statut :** `CANDIDATE_AFTER_1M_IMPLEMENTATION_FALSIFICATION`

## Nouvelle brique : Opposed Pair Gate V1.1

Ajouter à la chaîne canonique, après construction des cadres et mesure des deux trajectoires, avant l'agrégation K3 finale :

`Frames → Pair preregistration → dual S measurements → OPG → K3 → Amygdale → Surface → ZMOS`

### Invariant P1 — pré-déclaration
L'opposé/contraste et sa règle doivent être gelés avant observation des résultats.

### Invariant P2 — parité
Les deux branches utilisent les mêmes cadres, baseline, profondeur, horizon et politique de mesure.

### Invariant P3 — anti-compensation
Aucune moyenne globale ne peut masquer une régression de cadre. Le verdict directionnel fort exige la direction cohérente sur tous les cadres requis.

### Invariant P4 — inconnue
Tout cadre requis non mesuré produit `opposed_pair_evidence=NON_MESURÉ` et interdit une revendication directionnelle.

### Invariant P5 — séparation des opérateurs
`OPPOSÉ != NON(K3) != INVERSE != ROLLBACK`.

### Invariant P6 — veto
Amygdale demeure supérieure à OPG et peut bloquer toute sortie/action.

### Invariant P7 — confiance externe
Les reçus hachés ne deviennent admissibles que si leurs empreintes sont résolues
depuis une liste de confiance externe au paquet. Sans cela, le résultat reste
`NON_MESURÉ`.

### Invariant P8 — séparation preuve/direction
`opposed_pair_evidence=PASS` atteste la qualité des preuves, pas la direction.
Toute décision doit aussi exiger `opposed_pair_direction=PASS`.

## Mise à jour §15 Robot de consolidation

Ajouter entre les opérations actuelles 5 et 6 :
- rechercher/valider la règle de contraste ;
- produire le `opposed_pair_spec` avant patch ;
- évaluer les deux branches en dry-run ;
- si règle absente : `PACK_REQUEST(OPPOSED_PAIR_RULE)` + `NON_MESURÉ`.

Aucune application réelle n'est autorisée par ce patch de plan.

## Critère de promotion de la brique

1. campagne déterministe 1 000 000 cas : 0 violation d'invariant ;
2. tests unitaires négatifs : PASS ;
3. contre-audit Work sur le code réel de K3/ZMOS/ZCE ;
4. intégration sur branche isolée uniquement ;
5. PRE K3 + Amygdale avant changement, POST K3 + Amygdale après ;
6. aucune régression des cadres pairs/supérieurs ;
7. rollback scellé avant toute mutation.
