# Placement canonique — K3 / Amygdale / ZMOS

## 1. K3

Ne jamais modifier la table de vérité K3 existante.

Le `OpposedPairGate` produit un verdict de qualité du reçu :
- `k3_verdict=PASS` : paire structurée, pré-déclarée, complètement mesurée ;
- `k3_verdict=NON_MESURÉ` : au moins un cadre requis n'est pas mesuré ;
- `k3_verdict=FAIL` : paire invalide, baseline non comparable, inverse non prouvé, confusion rollback, etc.

L'adapter publie cette qualité sous :

`opposed_pair_evidence`

Il publie séparément l'admissibilité de la direction candidate sous :

`opposed_pair_direction`

Lorsque la politique d'une décision exige le contraste, l'expression K3 finale
doit inclure **les deux** cadres par `ET`. Le cadre directionnel vaut `PASS`
uniquement pour `DIRECTIONAL_SUPPORT`, `FAIL` pour direction inversée,
dégradation double ou conflit de cadres, et `NON_MESURÉ` pour neutralité ou
absence de discrimination.

## 2. Amygdale

Amygdale reste l'étalon de veto. OPG ne l'autorise jamais à être contournée.

Recommandations OPG :
- `DIRECTIONAL_SUPPORT` → `NO_VETO_FROM_OPG` (les autres vetos restent actifs) ;
- `DIRECTION_REVERSED` → veto de la direction candidate ;
- `FRAME_CONFLICT`, `BOTH_DEGRADE` → veto ;
- `NON_DISCRIMINATING`, `NEUTRAL` → HOLD ;
- `NON_MESURÉ`, `REJECT` → veto fail-closed.

## 3. ZMOS

Créer trois objets immuables :
1. `opposed_pair_spec` — écrit **avant** l'essai et lié à un reçu de
   pré-enregistrement figurant dans une liste de confiance externe ;
2. `opposed_pair_measurement_set` — deux branches, mêmes cadres ;
3. `opposed_pair_receipt` — résultat OPG + K3 + Amygdale.

Relations typées :
- `OPPOSES` / `CONTRASTS_WITH`
- `MEASURED_BY`
- `DERIVED_FROM`
- `VALIDATED_BY_K3`
- `VETOED_BY_AMYGDALA`

`ROLLBACK_OF` demeure une relation distincte et n'est jamais synonyme de `OPPOSES`.

Les identités ZMOS doivent conserver la grammaire canonique du dépôt : objets, relations et reçus sont content-addressed et hachés.

Les empreintes des reçus de pré-enregistrement et de mesure doivent être
résolues depuis une provenance distincte du paquet OPG. Une empreinte simplement
recopiée par l'appelant ne prouve aucune autorité productive.
